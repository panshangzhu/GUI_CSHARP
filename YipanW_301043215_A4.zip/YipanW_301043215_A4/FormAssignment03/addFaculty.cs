﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class addFaculty : Form
    {

        public addFaculty()
        {
            InitializeComponent();
        }

        

        private void onClickAdd(object sender, EventArgs e)
        {
            try
            {
                mainForm mainRef = Application.OpenForms["mainForm"] as mainForm;
                Faculty newFaculty = new Faculty(txtName.Text, new Address(txtStreet.Text, txtCity.Text, txtProvince.Text),
                    long.Parse(txtPhone.Text));
                newFaculty.StartOfEmployment = startDate.Value;
                mainRef.facultyArray.Add(newFaculty);
                mainRef.facultiesSave.Add(newFaculty);
                this.Close();
            }
            catch (Exception c)
            {
                txtError.Visible = true;
                txtError.Text = c.ToString();
            }
        }
    }
}

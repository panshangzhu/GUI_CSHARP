﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class addCourse : Form
    {
        internal ArrayList courseCode;
        ArrayList a;
        
        public addCourse()
        {
            InitializeComponent();
            courseCode = new ArrayList();
            a = new ArrayList();
            a.Add(CourseSubject.BSAF);
            a.Add(CourseSubject.CECP);
            a.Add(CourseSubject.COMP);
            
            
        }

        private void onLoadShow(object sender, EventArgs e)
        {
            lstCourseCode.Items.AddRange(a.ToArray());
            a.Clear();
        }

        private void onClickAddCourse(object sender, EventArgs e)
        {
            addAssignment assgnRef = Application.OpenForms["addAssignment"] as addAssignment;
            Course c = new Course((CourseSubject)lstCourseCode.SelectedItem, int.Parse(txtCouseNo.Text), txtCourseName.Text);
            assgnRef.courseArray.Add(c);
            
            this.Close();
        }

        private void onClickCancel(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

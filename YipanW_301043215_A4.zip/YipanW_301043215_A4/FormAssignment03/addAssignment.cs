﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class addAssignment : Form
    {
        //fields
        internal ArrayList courseArray;
        ArrayList addedArray;
        private addCourse newCourse;
        internal List<TeachingCourse> teachingCourses;
        
        public addAssignment()
        {
            InitializeComponent();
            courseArray = new ArrayList();
        
           
            addedArray = new ArrayList();
            newCourse = new addCourse();
            teachingCourses = new List<TeachingCourse>();
            //teachingCourses.Add(new TeachingCourse(course1, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));
            //teachingCourses.Add(new TeachingCourse(course2, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));
            //teachingCourses.Add(new TeachingCourse(course3, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));
            //teachingCourses.Add(new TeachingCourse(course4, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));
            //teachingCourses.Add(new TeachingCourse(course5, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));
            //teachingCourses.Add(new TeachingCourse(course6, new DateTime(2019, 3, 7), new DateTime(2019, 6, 9)));

        }

        private void onActivatedDisplay(object sender, EventArgs e)
        {
            lstCourse.Items.Clear();
            Course course1 = new Course(CourseSubject.BSAF, 100, "Introduction to Business");
            Course course2 = new Course(CourseSubject.BSAF, 320, "Project Management");
            Course course3 = new Course(CourseSubject.CECP, 101, "PC Hardware");
            Course course4 = new Course(CourseSubject.CECP, 257, "The Physical Layer");
            Course course5 = new Course(CourseSubject.COMP, 120, "Programming I");
            Course course6 = new Course(CourseSubject.COMP, 228, "Introduction to Java");

            courseArray.Add(course1);
            courseArray.Add(course2);
            courseArray.Add(course3);
            courseArray.Add(course4);
            courseArray.Add(course5);
            courseArray.Add(course6);
            lstCourse.Items.AddRange(this.courseArray.ToArray());
            this.courseArray.Clear();
        }

        private void onClickAssign(object sender, EventArgs e)
        {
            this.addedArray.Clear();
            for(int i = 0; i < lstCourse.CheckedItems.Count; i++)
            {
            addedArray.Add(lstCourse.CheckedItems[i]);
            }
            //addedArray.Add(lstCourse.SelectedItem);
            lstAdd.Items.AddRange(addedArray.ToArray());

            while(lstCourse.CheckedItems.Count>0)
            {
                lstCourse.Items.RemoveAt(lstCourse.CheckedIndices[0]);
            }
            //lstCourse.Items.Remove(lstCourse.SelectedItem);
        }

        private void onClickOk(object sender, EventArgs e)
        {
            mainForm mainRef = Application.OpenForms["mainForm"] as mainForm;
            //this.addedArray.Clear();
            // this.addedArray.AddRange(lstAdd.Items);
            //mainRef.addedCourseArray = this.addedArray;
            for (int a = 0; a < lstAdd.Items.Count; a++)
            {
                    mainRef.facultiesSave.Faculties[mainRef.facultyIndex].AddQualifiedCourse((Course)lstAdd.Items[a]);
                
                    TeachingCourse newTCourse=new TeachingCourse((Course)lstAdd.Items[a],new DateTime(2019,3,1),new DateTime(2019,9,1));
                    for(int i=0;i<teachingCourses.Count;i++)
                {
                    if (newTCourse.course == teachingCourses[i].course)
                    {
                        Course removeitem = teachingCourses[i].FacultyTeaching.assignedCourses.Single(c => c == newTCourse.course);
                        teachingCourses[i].FacultyTeaching.assignedCourses.Remove(removeitem);
                        mainRef.teachingList.Remove(teachingCourses[i]);
                        teachingCourses.Remove(teachingCourses[i]);

                    }
                }
                    newTCourse.AssignFaculty(mainRef.facultiesSave.Faculties[mainRef.facultyIndex]);
                    teachingCourses.Add(newTCourse);
            }
            mainRef.teachingList.AddRange(teachingCourses);
            lstAdd.Items.Clear();
            this.Close();
        }

        private void onClickBack(object sender, EventArgs e)
        {
            courseArray.Add(lstAdd.SelectedItem);
            lstCourse.Items.AddRange(courseArray.ToArray());
            this.courseArray.Clear();
            lstAdd.Items.Remove(lstAdd.SelectedItem);
        }

        private void onClickAddCourse(object sender, EventArgs e)
        {
            newCourse.ShowDialog();
        }

     

        private void onClickCancel(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

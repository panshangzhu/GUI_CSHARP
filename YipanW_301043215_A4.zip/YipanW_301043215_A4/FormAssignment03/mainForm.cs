﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class mainForm : Form
    {
        internal ArrayList facultyArray;
        private addFaculty facultyFrom;
        private addAssignment assignmentForm;
        //internal ArrayList addedCourseArray;
        internal FacultyRepository facultiesSave;
        internal int facultyIndex;
        internal List<TeachingCourse> teachingList;
        public mainForm()
        {
            InitializeComponent();
            facultyArray = new ArrayList();
            //addedCourseArray = new ArrayList();
            facultyFrom = new addFaculty();
            assignmentForm = new addAssignment();
            facultiesSave = new FacultyRepository();
            teachingList = new List<TeachingCourse>();
            facultyIndex = lstFaculty.SelectedIndex;
            
        }

        private void onClickFaculty(object sender, EventArgs e)
        {
          
            facultyFrom.ShowDialog();
        }

        private void onActivatedShow(object sender, EventArgs e)
        {
            lstCourse.Items.Clear();
            lstFaculty.Items.AddRange(this.facultyArray.ToArray());
            this.facultyArray.Clear();
            if (lstFaculty.SelectedIndex >= 0)
            {
                lstCourse.Items.AddRange(facultiesSave.Faculties[lstFaculty.SelectedIndex].assignedCourses.ToArray());
            }
            //this.addedCourseArray.Clear();
        }

        private void onClickAssignment(object sender, EventArgs e)
        {
            if (lstFaculty.SelectedIndex == -1)
            {
                lblError.Visible = true;
            }
            else
            {
                lstCourse.Items.Clear();
                assignmentForm.ShowDialog();
            }
        }

        private void onClickSave(object sender, EventArgs e)
        {
            //facultyArray.Add(lstFaculty.SelectedItem.ToString());
            //for(int b = 0; b < lstCourse.Items.Count; b++)
            //{
            //    addedCourseArray.Add(lstCourse.Items[b].ToString());
            //}
            facultiesSave.Save("FacultiesAndCourse.json");
            this.Close();
            
        }

        private void BtnShowFaculty_Click(object sender, EventArgs e)
        {
            lstAssignedFaculty.Items.Clear();
            List<Faculty> NoCoursesFaculties = new List<Faculty>();
            NoCoursesFaculties.AddRange(facultiesSave.getNoCourseFaculty().ToArray());
            for(int i = 0; i < NoCoursesFaculties.Count; i++)
            {
                lstAssignedFaculty.Items.Add(NoCoursesFaculties[i].Name);
            }
            NoCoursesFaculties.Clear();
            //lstAssignedFaculty.Items.AddRange(facultiesSave.getHaveCourseFaculty().ToArray());
        }

        private void BtnCheckFaculty_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < teachingList.Count; i++)
            {
                if (this.txtInput.Text == teachingList[i].CourseCode)
                {
                    this.txtOutput.Text = teachingList[i].FacultyTeaching.Name;
                    return;
                }
                else
                {
                    this.txtOutput.Text = "cannot find course or no faculty was assigned to this course";
                }
            }
        }

        private void onSelectedChange(object sender, EventArgs e)
        {
            facultyIndex = lstFaculty.SelectedIndex;
            if (lstFaculty.SelectedIndex >= 0)
            {
                lstCourse.Items.Clear();
                lstCourse.Items.AddRange(facultiesSave.Faculties[lstFaculty.SelectedIndex].assignedCourses.ToArray());
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public class TeachingCourse
    {

        private string courseCode;
        public string CourseCode
        {
            get { return courseCode; }
            set { courseCode = value; }
        }

        private Faculty facultyTeaching;
        public Faculty FacultyTeaching
        {
            get { return facultyTeaching; }
            set { facultyTeaching = value; }
        }
        private DateTime startdate;
        public DateTime StartDate
        {
            get { return startdate; }
            set { startdate = value; }
        }
        private DateTime enddate;
        public DateTime EndDate
        {
            get { return enddate; }
            set { enddate = value; }
        }
        private bool canceled;
        public bool Canceled
        {
            get { return canceled; }
            set { canceled = value; }
        }
        private Course course;

        public bool AssignFaculty(Faculty f)
        {
            if (!f.IsQualified(course))
            {
                Console.WriteLine( $"{f.Name} is not qualified to teach {course.CourseCode}!");
                return false;
            }
            FacultyTeaching = f;
            return true;
        }
        private string ifCancell;
        private string checkCancell()
        {
            if (Canceled == false)
            {
                ifCancell = "This course is not cancelled";
            }
            else
            {
                ifCancell = "This course is cancelled";
            }
            return ifCancell;
        }

        public TeachingCourse(Course teachingCourse, DateTime start, DateTime end)
        {
            course = teachingCourse;
            CourseCode = teachingCourse.Subject.ToString() + teachingCourse.Number;
            StartDate = start;
            EndDate = end;
            facultyTeaching = null;

            
        }
        public string GetInfo()
        {
            if (FacultyTeaching == null)
            return $"{CourseCode},0, Faculty not assigned, {StartDate.ToShortDateString()} to {EndDate.ToShortDateString()}\n";
            else
            return $"{CourseCode}, {FacultyTeaching.EmployeeNumber}, {FacultyTeaching.Name}, {StartDate.ToShortDateString()} to {EndDate.ToShortDateString()}\n";


        }
        public override string ToString()
        {
            return GetInfo();
        }

    }
}

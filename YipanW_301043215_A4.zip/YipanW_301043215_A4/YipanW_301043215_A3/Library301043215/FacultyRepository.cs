﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public class FacultyRepository : RepositoryBase
    {
        private int noOfFaculties;
        public int NoOfFaculties
        {
            get { return noOfFaculties; }
        }
        public override List<Faculty> Faculties { get ; set; }
        public void Add(Faculty f)
        {
            //f.EmployeeNumber = UniqueIdService.getNewId();
            Faculties.Add(f);
        }

    }
}

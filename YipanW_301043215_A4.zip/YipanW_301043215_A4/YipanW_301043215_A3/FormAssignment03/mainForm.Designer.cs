﻿namespace FormAssignment03
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstFaculty = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddAssignment = new System.Windows.Forms.Button();
            this.btnAddFaculty = new System.Windows.Forms.Button();
            this.lblFaculty = new System.Windows.Forms.Label();
            this.lblCourse = new System.Windows.Forms.Label();
            this.lstCourse = new System.Windows.Forms.ListBox();
            this.lblError = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstFaculty
            // 
            this.lstFaculty.BackColor = System.Drawing.SystemColors.Info;
            this.lstFaculty.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstFaculty.FormattingEnabled = true;
            this.lstFaculty.ItemHeight = 15;
            this.lstFaculty.Location = new System.Drawing.Point(23, 63);
            this.lstFaculty.Name = "lstFaculty";
            this.lstFaculty.Size = new System.Drawing.Size(300, 289);
            this.lstFaculty.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnAddAssignment);
            this.panel1.Controls.Add(this.btnAddFaculty);
            this.panel1.Location = new System.Drawing.Point(348, 192);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(364, 160);
            this.panel1.TabIndex = 1;
            // 
            // btnAddAssignment
            // 
            this.btnAddAssignment.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddAssignment.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddAssignment.Location = new System.Drawing.Point(207, 51);
            this.btnAddAssignment.Name = "btnAddAssignment";
            this.btnAddAssignment.Size = new System.Drawing.Size(110, 50);
            this.btnAddAssignment.TabIndex = 1;
            this.btnAddAssignment.Text = "Add Assignment";
            this.btnAddAssignment.UseVisualStyleBackColor = false;
            this.btnAddAssignment.Click += new System.EventHandler(this.onClickAssignment);
            // 
            // btnAddFaculty
            // 
            this.btnAddFaculty.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddFaculty.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFaculty.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddFaculty.Location = new System.Drawing.Point(34, 51);
            this.btnAddFaculty.Name = "btnAddFaculty";
            this.btnAddFaculty.Size = new System.Drawing.Size(110, 50);
            this.btnAddFaculty.TabIndex = 0;
            this.btnAddFaculty.Text = "Add Faculty";
            this.btnAddFaculty.UseVisualStyleBackColor = false;
            this.btnAddFaculty.Click += new System.EventHandler(this.onClickFaculty);
            // 
            // lblFaculty
            // 
            this.lblFaculty.AutoSize = true;
            this.lblFaculty.Font = new System.Drawing.Font("Lucida Sans", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFaculty.Location = new System.Drawing.Point(23, 37);
            this.lblFaculty.Name = "lblFaculty";
            this.lblFaculty.Size = new System.Drawing.Size(96, 17);
            this.lblFaculty.TabIndex = 2;
            this.lblFaculty.Text = "Faculty Info";
            // 
            // lblCourse
            // 
            this.lblCourse.AutoSize = true;
            this.lblCourse.Font = new System.Drawing.Font("Lucida Sans", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourse.Location = new System.Drawing.Point(345, 37);
            this.lblCourse.Name = "lblCourse";
            this.lblCourse.Size = new System.Drawing.Size(96, 17);
            this.lblCourse.TabIndex = 3;
            this.lblCourse.Text = "Course Info";
            // 
            // lstCourse
            // 
            this.lstCourse.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lstCourse.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCourse.FormattingEnabled = true;
            this.lstCourse.ItemHeight = 15;
            this.lstCourse.Location = new System.Drawing.Point(348, 63);
            this.lstCourse.Name = "lstCourse";
            this.lstCourse.Size = new System.Drawing.Size(364, 109);
            this.lstCourse.TabIndex = 4;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.Maroon;
            this.lblError.Location = new System.Drawing.Point(57, 366);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(213, 15);
            this.lblError.TabIndex = 5;
            this.lblError.Text = "Please Add or Select a Faculty";
            this.lblError.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnSave.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(467, 381);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(110, 50);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.onClickSave);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.lstCourse);
            this.Controls.Add(this.lblCourse);
            this.Controls.Add(this.lblFaculty);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lstFaculty);
            this.MaximumSize = new System.Drawing.Size(800, 500);
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.Name = "mainForm";
            this.Text = "Main Form";
            this.Activated += new System.EventHandler(this.onActivatedShow);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstFaculty;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAddAssignment;
        private System.Windows.Forms.Button btnAddFaculty;
        private System.Windows.Forms.Label lblFaculty;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.ListBox lstCourse;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Button btnSave;
    }
}


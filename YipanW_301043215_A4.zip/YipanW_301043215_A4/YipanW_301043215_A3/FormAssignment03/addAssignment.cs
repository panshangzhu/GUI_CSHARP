﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class addAssignment : Form
    {
        //fields
        internal ArrayList courseArray;
        ArrayList addedArray;
        private addCourse newCourse;
        
        public addAssignment()
        {
            InitializeComponent();
            courseArray = new ArrayList();
            courseArray.Add(new Course(CourseSubject.BSAF, 100, "Introduction to Business"));
            courseArray.Add(new Course(CourseSubject.BSAF, 320, "Project Management"));
            courseArray.Add(new Course(CourseSubject.CECP, 101, "PC Hardware"));
            courseArray.Add(new Course(CourseSubject.CECP, 257, "The Physical Layer"));
            courseArray.Add(new Course(CourseSubject.COMP, 120, "Programming I"));
            courseArray.Add(new Course(CourseSubject.COMP, 228, "Introduction to Java"));
            //courseArray.Add("BSAF320            Project Management");
            //courseArray.Add("CECP101                   PC Hardware");
            //courseArray.Add("CECP257            The Physical Layer");
            //courseArray.Add("COMP120                 Programming I");
            //courseArray.Add("COMP228          Introduction to Java");
            addedArray = new ArrayList();
            newCourse = new addCourse();

        }

        private void onLoadDisplay(object sender, EventArgs e)
        {
            
            lstCourse.Items.AddRange(this.courseArray.ToArray());
            this.courseArray.Clear();
        }

        private void onClickAssign(object sender, EventArgs e)
        {
            this.addedArray.Clear();
            for(int i = 0; i < lstCourse.CheckedItems.Count; i++)
            {
            addedArray.Add(lstCourse.CheckedItems[i]);
            }
            //addedArray.Add(lstCourse.SelectedItem);
            lstAdd.Items.AddRange(addedArray.ToArray());

            while(lstCourse.CheckedItems.Count>0)
            {
                lstCourse.Items.RemoveAt(lstCourse.CheckedIndices[0]);
            }
            //lstCourse.Items.Remove(lstCourse.SelectedItem);
        }

        private void onClickOk(object sender, EventArgs e)
        {
            mainForm mainRef = Application.OpenForms["mainForm"] as mainForm;
            mainRef.addedCourseArray = this.addedArray;
            for (int a = 0; a < lstAdd.Items.Count; a++)
            {
                    mainRef.facultiesSave.Faculties[mainRef.facultyIndex].AddQualifiedCourse((Course)lstAdd.Items[a]);    
            }
            lstAdd.Items.Clear();
            this.Close();
        }

        private void onClickBack(object sender, EventArgs e)
        {
            courseArray.Add(lstAdd.SelectedItem);
            lstCourse.Items.AddRange(courseArray.ToArray());
            this.courseArray.Clear();
            lstAdd.Items.Remove(lstAdd.SelectedItem);
        }

        private void onClickAddCourse(object sender, EventArgs e)
        {
            newCourse.ShowDialog();
        }

        private void onActivatedDisplay(object sender, EventArgs e)
        {
            lstCourse.Items.AddRange(this.courseArray.ToArray());
            this.courseArray.Clear();
        }

        private void onClickCancel(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

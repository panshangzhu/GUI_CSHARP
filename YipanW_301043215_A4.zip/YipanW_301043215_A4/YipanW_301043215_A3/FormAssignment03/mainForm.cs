﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library301043215;

namespace FormAssignment03
{
    public partial class mainForm : Form
    {
        internal ArrayList facultyArray;
        private addFaculty facultyFrom;
        private addAssignment assignmentForm;
        internal ArrayList addedCourseArray;
        internal FacultyRepository facultiesSave;
        internal int facultyIndex;

        public mainForm()
        {
            InitializeComponent();
            facultyArray = new ArrayList();
            addedCourseArray = new ArrayList();
            facultyFrom = new addFaculty();
            assignmentForm = new addAssignment();
            facultiesSave = new FacultyRepository();
        }

        private void onClickFaculty(object sender, EventArgs e)
        {
          
            facultyFrom.ShowDialog();
        }

        private void onActivatedShow(object sender, EventArgs e)
        {
            lstFaculty.Items.AddRange(this.facultyArray.ToArray());
            this.facultyArray.Clear();
            lstCourse.Items.AddRange(this.addedCourseArray.ToArray());
            this.addedCourseArray.Clear();
        }

        private void onClickAssignment(object sender, EventArgs e)
        {
            if (lstFaculty.SelectedIndex == -1)
            {
                lblError.Visible = true;
            }
            else
            {
                facultyIndex = lstFaculty.SelectedIndex;
                lstCourse.Items.Clear();
                assignmentForm.ShowDialog();
            }
        }

        private void onClickSave(object sender, EventArgs e)
        {
            //facultyArray.Add(lstFaculty.SelectedItem.ToString());
            //for(int b = 0; b < lstCourse.Items.Count; b++)
            //{
            //    addedCourseArray.Add(lstCourse.Items[b].ToString());
            //}
            facultiesSave.Save("FacultiesAndCourse.json");
            this.Close();
            
        }
    }
}

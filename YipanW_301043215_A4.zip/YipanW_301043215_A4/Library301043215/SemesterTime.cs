﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public enum SemesterTime { FALL, WINTER, SUMMER }
}

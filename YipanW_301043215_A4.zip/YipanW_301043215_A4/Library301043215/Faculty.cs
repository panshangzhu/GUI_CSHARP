﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    [Serializable]
    public class Faculty
    {
        private int employeeNumber;
        public int EmployeeNumber
        {
            get { return employeeNumber; }
            set
            {
                if (value > 0) { employeeNumber = value; }
                else { employeeNumber = 9999; }
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private DateTime startOfEmployment;
        public DateTime StartOfEmployment
        {
            get { return startOfEmployment; }
            set { startOfEmployment = value; }
        }
        private Address add;
        public Address Address
        {
            get { return add; }
            set { add = value; }
        }

        public string displayAddress()
        {
            return $"{Address.street},{Address.city},{Address.province}";
        }

        private long telNumber;
        public long TelephonNumber
        {
            get { return telNumber; }
            set { telNumber = value; }
        }
        private List<string> emails;
        public List<string> Emails
        {
            get { return emails; }
            set { emails = value; }
        }

        private List<Course> cours;
        public List<Course> courses
        {
            get { return cours; }
            set { cours = value; }
        }
        private int noOfCourses;
        public int NoOfCourses
        {
            get { return noOfCourses; }
            set { noOfCourses = value; }
        }
        private int noOfEmail;
        public int NoOfEmail
        {
            get { return noOfEmail; }
            set { noOfEmail = value; }
        }
        public List<Course> assignedCourses;

        public Faculty(string name, Address a, long telNumber)
        {
            EmployeeNumber = UniqueIdService.getNewId();
            Name = name;
            TelephonNumber = telNumber;
            courses = new List<Course>();
            emails = new List<string>();
            Address = a;
            assignedCourses = new List<Course>();
            
        }
        public Faculty()
        {
            EmployeeNumber = UniqueIdService.getNewId();
            cours = new List<Course>();
            emails = new List<string>();
            assignedCourses = new List<Course>();

        }
        public string getAssigndCourse()
        {
            string e = "";
            for(int i = 0; i < assignedCourses.Count; i++)
            {
                e += assignedCourses[i] + ",";
            }
            return e;
        }

        public List<Course> AddQualifiedCourse(Course c)
        {
            courses.Add(c);
            return courses;
        }
        public string GetCourse()
        {
            string e = "";
            for (int i = 0; i < NoOfCourses; i++)
            {
                e += "\t" + courses[i].GetInfo() + "\n";
            }
            return e;
        }
        public bool IsQualified(Course c)
        {
            for (int i = 0; i < courses.Count; i++)
            {
                if (courses[i].CourseCode == c.CourseCode)
                {
                    return true;
                }
            }
            return false;
        }
        public List<string> AddEmail(string newEmail)
        {
            Emails.Add(newEmail);
            return Emails;
        }

        public string GetEmail()
        {
            string e = "";
            for (int i = 0; i < NoOfEmail; i++)
            {
               
                    e += "\t" + Emails[i] + "\n";
                
               
           
            }
            return e;
        }


        public string GetInfo()
        {
            return $"\nEmp#: {EmployeeNumber} {Name}" +
                $" Started: {StartOfEmployment.ToShortDateString()}\n" +
                $"Address:{displayAddress()}" +
                $" Tel:{TelephonNumber}\n"+
                $"Emails:\n{GetEmail()}"+
                $"Courses teaching:\n{GetCourse()}";
        }
        public override string ToString()
        {
            return $"{EmployeeNumber}, {Name}, {TelephonNumber}, {displayAddress()}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public class CECourse:Course
    {
        private int breakEvenEnrolement;
        public int BreakEvenEnrolement
        {
            get { return breakEvenEnrolement; }
            set { breakEvenEnrolement = value; }
        }
        public CECourse(CourseSubject subject, int number, string title,int breakEvenEnrolement):base(subject, number, title)
        {
            BreakEvenEnrolement = breakEvenEnrolement;
        }
        public override string GetInfo()
        {
            return $"{base.GetInfo()} brake Even:{BreakEvenEnrolement}";
        }
    }
}

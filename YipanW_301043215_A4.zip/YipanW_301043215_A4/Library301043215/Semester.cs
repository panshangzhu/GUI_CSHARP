﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public class Semester
    {
        
        private SemesterTime sem;
        public SemesterTime SemesterTime
        {
            get { return sem; }
            set { sem = value; }
        }
        private int year;
        public int SchoolYear
        {
            get { return year; }
            set { year = value; }
        }
        private List<TeachingCourse> courseOffered;
        public List<TeachingCourse> CoursesOffered
        {
            get { return courseOffered; }
            set { courseOffered = value; }
        }

        private int NoOfCourse;
        public Semester(SemesterTime s, int year)
        {
            SemesterTime = s;
            SchoolYear = year;
            courseOffered = new List<TeachingCourse>();
            
        }
        public Semester()
        {
            courseOffered = new List<TeachingCourse>();
        }
      
        public List<TeachingCourse> AddTeachingCourse(Course newCourse,DateTime startTime,DateTime endTime)
        {
            TeachingCourse newTeachingCourse = new TeachingCourse(newCourse, startTime, endTime);
            CoursesOffered.Add(newTeachingCourse);
            return CoursesOffered;
        }
        public string getCoursesOffered()
        {
            string o = "";
            for (int i = 0; i < CoursesOffered.Count; i++)
            {
                o += CoursesOffered[i].GetInfo();
            }
           
            return o;
        }

        public string GetInfo()
        {
            return $"Semester: {SemesterTime}{year}\n Offered courses:\n{getCoursesOffered()}";
        }
        public override string ToString()
        {
            return GetInfo();
        }
    }
}

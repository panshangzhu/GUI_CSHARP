﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    [Serializable]
    public class Course
    {
        private int number;
        public int Number
        {
            get { return number; }
            set { number = value; }
        }
       

        private CourseSubject subject;
        public CourseSubject Subject
        {
            get { return subject; }
            set { subject = value; }
        }
        private string title;
        public String Title
        {
            get { return title; }
            set { title = value; }
        }
        public string CourseCode
        {
            get { return Subject.ToString() + Number; }
        
        }
        public Course(CourseSubject subject, int number, string title)
        {
            Subject = subject;
            Number = number;
            Title = title;
        }
        public Course()
        {
           
        }

        public virtual string GetInfo()
        {
            return $"{CourseCode} {Title}";
                    
        }

        public override string ToString()
        {
            return GetInfo();
        }

        public static bool operator==(Course a, Course b)
        {
            return a.CourseCode == b.CourseCode;

        }
        public static bool operator!=(Course a,Course b)
        {
            return a.CourseCode != b.CourseCode;
        }

    }
}

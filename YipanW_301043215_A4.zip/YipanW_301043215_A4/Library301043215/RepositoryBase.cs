﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Library301043215
{
    abstract public class RepositoryBase
    {
        
        abstract public List<Faculty> Faculties
        {
            get;
            set;
        }
        public RepositoryBase()
        {
            Faculties = new List<Faculty>();
        } 
        public void Save(string filename)
        {
            FileStream fileOut = new FileStream(filename, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(fileOut);
            JsonSerializer serilizer = JsonSerializer.Create(
                new JsonSerializerSettings { Formatting = Formatting.Indented });
            serilizer.Serialize(writer, Faculties);
            writer.Close();
            fileOut.Close();
        }
        public void Load(string filename)
        {

            FileStream fileIn = new FileStream(filename, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(fileIn);
            JsonSerializer serilizer = JsonSerializer.Create(new JsonSerializerSettings { Formatting = Formatting.Indented });
            Faculties = serilizer.Deserialize(reader, typeof(List<Faculty>)) as List<Faculty>;
            reader.Close();
            fileIn.Close();
            
        }
    }
}

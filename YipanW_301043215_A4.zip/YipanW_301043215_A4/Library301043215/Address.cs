﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public struct Address
    {
        public string street, city, province;
        public Address(string street, string city, string province)
        {
           
            this.street = street;
            this.city = city;
            this.province = province;
        }
    }

  
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    static class UniqueIdService
    {
        private static int lastId;
        public static int getNewId()
        {
            return ++lastId;
        }
    }
}

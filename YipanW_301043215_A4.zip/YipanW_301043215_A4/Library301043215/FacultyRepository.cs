﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library301043215
{
    public class FacultyRepository : RepositoryBase
    {
        private int noOfFaculties;
        public int NoOfFaculties
        {
            get { return noOfFaculties; }
        }
        public override List<Faculty> Faculties { get ; set; }
        public List<Faculty> noCourseFaculty;
        public List<Faculty> haveCourseFaculty;
        public FacultyRepository()
        {
            noCourseFaculty = new List<Faculty>();
            haveCourseFaculty = new List<Faculty>();
        }
        public void Add(Faculty f)
        {
            //f.EmployeeNumber = UniqueIdService.getNewId();
            Faculties.Add(f);
        }
        public List<Faculty> getNoCourseFaculty()
        {
            noCourseFaculty = Faculties.Where(faculty => faculty.assignedCourses.Count == 0).ToList();
            Console.WriteLine("Faculties do not have courses");
            foreach (Faculty f in noCourseFaculty)
            {
                Console.WriteLine(f.Name);
            }
            return noCourseFaculty;
        }
        public List<Faculty> getHaveCourseFaculty()
        {
            haveCourseFaculty = (from faculty in Faculties
                                where faculty.assignedCourses.Count > 0
                                select faculty).ToList();

            //Faculties.Where(faculty => faculty.assignedCourses.Count > 0).ToList();
            Console.WriteLine("Faculties have courses");
            foreach (Faculty f in haveCourseFaculty)
            {
                
                Console.WriteLine(f.Name);
            }
            return haveCourseFaculty;
        }
        



    }
}
